import Component from "../payment-methods"

export default function Page() {
  return <Component />
}
